#ifndef COMMONVALS
#define COMMONVALS
#include "stb_image.h"

const int MAX_POINT_LIGHTS = 4; //La suma no pasa de 7, se declaran en shader_light.frag
const int MAX_SPOT_LIGHTS = 4; //Solo hay 8 luces simultaneas
#endif